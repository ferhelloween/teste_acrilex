<?php

    require_once "../Global.php"; 

    set_time_limit(1200); //Define tempo limite de execução
    ERROR_REPORTING (E_ERROR);  //Somente exibe erros fatais  

    $opcao = isset($_GET['opcao']) ? $_GET['opcao'] : '';
    $valor = isset($_GET['valor']) ? $_GET['valor'] : '';    


    switch ($opcao) {
        case 'Salvar':

            try {
                $nome = $_REQUEST['Nome']; 
                $ano = $_REQUEST['Ano'];
                $cor = $_REQUEST['Cor']; 
                $valor = $_REQUEST['Valor']; 
                
                $recursos = new Recursos(); 
                $recursos->setName($nome); 
                $recursos->setYear($ano); 
                $recursos->setColor($cor);
                $recursos->setPantoneValue($valor); 
                
                //Instancia o Objeto 
                $recursos->criarRecurso(); 

                echo "
                <BR>
                 <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                    Cadastrado com Sucesso	
                 </p>	
             
                 <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                   <a href='../VIEW/Tabela.php>Clique aqui para retornar a tabela de Registro</a>
                 </p> 
                 "; 


              
            } catch (Exception $e) {
                Erro::trataErro($e);
            }

            break;
        
        case 'Alterar':
       
        try {
       
            $id = $_REQUEST['id'];
            $nome = $_REQUEST['Nome']; 
            $ano = $_REQUEST['Ano'];
            $cor = $_REQUEST['Cor']; 
            $valor = $_REQUEST['Valor']; 
        
            $recursos = new Recursos(); 
            $recursos->setId($id);
            $recursos->setName($nome); 
            $recursos->setYear($ano); 
            $recursos->setColor($cor);
            $recursos->setPantoneValue($valor); 
            
             //Instancia o Objeto 
            $recursos->editarRecurso(); 

        echo "
        <BR>
         <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
            Editado com Sucesso	
         </p>	
     
         <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
           <a href='../VIEW/Tabela.php>Clique aqui para retornar a tabela de Registro</a>
         </p> 
         "; 



         } catch (Exception $e) {
                Erro::trataErro($e);
            }
            break;  
            
        case 'Excluir': 
            
        try {
            $id = $_GET['id'];
            $recursos = new Recursos($id);
        
            $recursos->excluirRecurso(); 

            header('Location: ../VIEW/Tabela.php');
            } catch (Exception $e) {
                Erro::trataErro($e);
            }

            break;

        default:
            # vazio...
            break;
    } 

?>    