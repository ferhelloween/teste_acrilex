<?php

    require_once "../Global.php"; 

    set_time_limit(1200); //Define tempo limite de execução
    ERROR_REPORTING (E_ERROR);  //Somente exibe erros fatais  

    $opcao = isset($_GET['opcao']) ? $_GET['opcao'] : '';
    $valor = isset($_GET['valor']) ? $_GET['valor'] : '';    


    switch ($opcao) {
        case 'Salvar':

           try {

            $email = $_REQUEST['email']; 
            $primero = $_REQUEST['primeiro'];
            $segundo = $_REQUEST['segundo']; 
            $avatar = $_REQUEST['avatar'];
            
            $usuario = new Usuarios(); 
            $usuario->setEmail($email); 
            $usuario->setFirst($primero); 
            $usuario->setLast($segundo); 
            $usuario->setAvatar($avatar); 

            $usuario->criarUsuario(); 
            
            echo "
            <BR>
             <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                Cadastrado com Sucesso	
             </p>	
         
             <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
               <a href='../VIEW/Tabela.php>Clique aqui para retornar a tabela de Registro</a>
             </p> 
             "; 
        
           } catch (Exception $e) {
             Erro::trataErro($e);
           }

            break;
        
        case 'Alterar':

            try {
                $id = $_REQUEST['id'];
                $email = $_REQUEST['email']; 
                $primero = $_REQUEST['primeiro'];
                $segundo = $_REQUEST['segundo']; 
                $avatar = $_REQUEST['avatar'];
                
                $usuario = new Usuarios();
                $usuario->setId($id); 
                $usuario->setEmail($email); 
                $usuario->setFirst($primero); 
                $usuario->setLast($segundo); 
                $usuario->setAvatar($avatar); 
    
                $usuario->editarUsuario(); 
                
                echo "
                <BR>
                 <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                    Cadastrado com Sucesso	
                 </p>	
             
                 <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                   <a href='../VIEW/Tabela.php>Clique aqui para retornar a tabela de Registro</a>
                 </p> 
                 "; 
            
            } catch (Exception $e) {
               Erro::trataErro($e);
            }
           
            break;  
            
        case 'Excluir':
        
            try {
                $id = $_GET['id'];
                $recursos = new Usuarios($id);
        
                $recursos->excluirUsuario(); 

                header('Location: ../VIEW/Tabela.php');
           
            } catch (Exception $e) {
                Erro::trataErro($e);
            }
           
            break;

        default:
            # vazio...
            break;
    } 

?>    