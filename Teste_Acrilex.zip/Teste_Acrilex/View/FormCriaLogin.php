

<html> 
    <head> 
        <title>Teste Acrilex</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Teste para Acrilex">
        <meta name="author" content="Fernando Henrique">

        <!--Link para o Bootstrap CSS-->    
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!--Link para os JS Bootstraps--> 
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>   

        <style>
            fieldset { 
                 display: block;
                 margin-left: 2px;
                 margin-right: 2px;
                 padding-top: 0.35em;
                 padding-bottom: 0.625em;
                 padding-left: 0.75em;
                 padding-right: 0.75em;
                 border: 2px solid blue;
            }
        </style>
 
    </head>

    <body>
        <h5 class="text-center text-info">Novo Usuário</h5>  
        <form name="fLogin" method="POST">  
          
          <div class="form-group row">
              <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-4">
                 <input type="email" class="form-control" name="Email" id="inputEmail" placeholder="Email">
                </div>
           </div>

           <div class="form-group row">
              <label for="inputPass" class="col-sm-2 col-form-label">Senha</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="Senha" id="inputPass" placeholder="Senha">
              </div>
            </div> 

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" value="Registrar" name="Registrar" class="btn btn-primary" formAction="../ControllerLogin.php?opcao=Registrar">
                        Registrar
                    </button>
                </div>
            </div>
          
        </form>

        
    </body>

</html>