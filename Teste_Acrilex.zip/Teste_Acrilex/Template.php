<html> 
    <head>
        <title>Teste Acrilex</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Teste para Acrilex">
        <meta name="author" content="Fernando Henrique">

        <!--Link para o Bootstrap CSS-->    
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!--Link para os JS Bootstraps--> 
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>   

        <style>
            fieldset { 
                 display: block;
                 margin-left: 2px;
                 margin-right: 2px;
                 padding-top: 0.35em;
                 padding-bottom: 0.625em;
                 padding-left: 0.75em;
                 padding-right: 0.75em;
                 border: 2px solid blue;
            }
        </style>

    </head>

    <body>

        <h1 class="text-primary text-center" >Seja bem vindo ao sistema!</h1>
        <br>

        <div class="container-fluid">
            <fieldset class="enfeite">
                <form>
                    <br>
                    <div class="form-group row" style="margin-left: 550px; ">
                    <label for="inputEmail" class="sr-only">Usuário</label>
                    <div class="col-sm-4">
                        <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Usuário" required autofocus>
                    </div> 
                    </div>   

                    <div class="form-group row" style="margin-left: 550px; ">   
                    <label for="inputPassword" class="sr-only">Senha</label>
                    <div class="col-sm-4">
                        <input type="password" id="inputPassword" name="senha" class="form-control" placeholder="Senha" required>
                    </div> 
                    </div>   
                        
                    <button class="btn btn-primary" style="margin-left: 575px;" name="Logar" value="Logar" formaction="Controller/ControllerLogin.php" 
                    type="submit">Logar</button>
                    <button class="btn btn-primary" style="margin-left: 15px;" type="submit" data-toggle="modal" data-target="#modalCadastro">
                        Criar Novo Usuário
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h5 class="modal-title" id="exampleModalLabel">Registro de novo usuário</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" style="height: 300px; width: 700px;">
                            <iframe src="View/FormCriaLogin.php" style="width: 675px; height: 275px; border: none;">
                            </iframe>
                        </div>
                        <div class="modal-footer bg-primary">
                            <h3>Teste Acrilex</h3>
                        </div>
                    </div>
                    </div>
                </form> 
            </fieldset>
        </div>    
    </body>
</html>