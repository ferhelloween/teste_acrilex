<?php

require_once 'Model/Config.php';

spl_autoload_register('carregarClasse');

function carregarClasse($nomeClasse)
{
    if (file_exists('Model/' . $nomeClasse . '.php')) {
        require_once 'Model/' .$nomeClasse . '.php';
    }
}


?> 