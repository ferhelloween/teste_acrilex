<?php require_once "Cabecalho.php" ?>

<div class="row">
    <div class="col-md-12">
        <h2>Criar Novo Usuário</h2>
    </div>
</div>

<form method="post">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-group">
                <label for="nome">E-mail</label>
                <input name="email" type="text" class="form-control" placeholder="Email">
            </div>
            <div class="form-group">
                <label for="nome">Primeiro Nome</label>
                <input name="primeiro" type="text" class="form-control" placeholder="Primeiro Nome">
            </div>
            <div class="form-group">
                <label for="nome">Último Nome</label>
                <input name="segundo" type="text" class="form-control" placeholder="Último Nome">
            </div>
            <div class="form-group">
                <label for="nome">Avatar</label>
                <input name="avatar" type="text" class="form-control" placeholder="Avatar">
            </div>
            <button type="submit" class="btn btn-success btn-block" value="Salvar" name="Salvar" formaction="../Controller/ControllerUsuarios.php?opcao=Salvar">
                Salvar
            </button>
        </div>
    </div>
</form>
