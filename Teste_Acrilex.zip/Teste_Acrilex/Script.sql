CREATE DATABASE Acrilex; 

use Acrilex;


CREATE TABLE Users ( 
    id INT NOT NULL AUTO_INCREMENT,
    email VARCHAR(200) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    avatar VARCHAR(100) NOT NULL,
    PRIMARY KEY(id)
);

CREATE TABLE Resources ( 
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    year VARCHAR(10) NOT NULL,
    color VARCHAR(50) NOT NULL,
    pantone_value DOUBLE(9,2) NOT NULL, 
    PRIMARY KEY(id)
); 

CREATE TABLE Login (
    id INT NOT NULL AUTO_INCREMENT, 
    email VARCHAR(200) NOT NULL, 
    pass VARCHAR(200) NOT NULL, 
    PRIMARY KEY(id)
)

