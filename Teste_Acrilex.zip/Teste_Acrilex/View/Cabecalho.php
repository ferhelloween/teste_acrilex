<html> 
    <head>
        <title>Teste Acrilex</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Teste para Acrilex">
        <meta name="author" content="Fernando Henrique">

        <!--Link para o Bootstrap CSS-->    
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!--Link para os JS Bootstraps--> 
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>   

    </head>

    <body>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul class="navbar-nav">
                <li class="nav-item ">
                    <a class="nav-link" href="#">Início</a>
                 </li>
    
                
                <li class="nav-item">
                    <a class="nav-link" href="#">Sobre</a>
                </li>
                
             </ul>
        </nav>      


        <div class="container">    
          
