<?php require_once 'global.php' ?>
<?php
    try {
        $id = $_GET['id'];
        $usuario = new Usuarios($id);
    } catch (Exception $e) {
        Erro::trataErro($e);
    }
?>
<?php require_once 'cabecalho.php' ?>

<div class="row">
    <div class="col-md-12">
        <h2>Editar Usuário</h2>
    </div>
</div>

<form method="post">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $usuario->getId() ?>">
            
                <label for="nome">E-mail</label>
                <input name="nome" value="<?=$usuario->getEmail() ?>" type="text" class="form-control" placeholder="Email">
            </div>
            <div class="form-group">
                <label for="nome">Primeiro Nome</label>
                <input name="primeiro" value="<?=$usuario->getFirst() ?>" type="text" class="form-control" placeholder="Primeiro Nome">
            </div>
            <div class="form-group">
                <label for="nome">Último Nome</label>
                <input name="segundo" value="<?=$usuario->getLast() ?>" type="text" class="form-control" placeholder="Último Nome">
            </div>
            <div class="form-group">
                <label for="nome">Avatar</label>
                <input name="avatar" value="<?=$usuario->getAvatar() ?>" type="text" class="form-control" placeholder="Avatar">
            </div>
            <button type="submit" class="btn btn-success btn-block" value="Alterar" name="Alterar" formaction="../Controller/ControllerUsuarios.php?opcao=Alterar">
                Alterar
            </button>
        </div>
    </div>
</form>
