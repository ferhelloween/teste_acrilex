<?php

    require_once "Conexao.php";

    class Login { 

        protected $id; 
        protected $email; 
        protected $password;
        
        public function __consruct($id, $email, $password) { 
            $this->id = $id; 
            $this->email = $email; 
            $this->password = $password;

        }

        //Funções Getters
        public function getId() { 
            return $this->id;             
        }

        public function getEmail() { 
            return $this->email; 
        }

        public function getPassword() { 
            return $this->password; 
        }

        //Funções Setters 
        public function setId($id) { 
            $this->id = $id; 
        }

        public function setEmail($email) { 
            $this->email = $email; 
        }

        public function setPassword($password) { 
            $this->password = $password; 
        }

        public function criarLogin() { 
            $query = "
                INSERT INTO Login(email, pass) VALUES (:email, :pass) 
            ";    
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':email', $this->getEmail()); 
            $stmt->bindValue(':pass', $this->getPassword()); 
            $stmt->execute(); //Executa a Consulta     
        }

        public function tratarLogin($email, $password) {
            $passMd5 = md5($password);
            $query = "
                SELECT email, pass from Login WHERE email = '{$email}' AND pass = '{$passMd5}'
            ";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->query($query); 
            $usuario = $stmt->fetch(); 

            return $usuario; //Retorna o Usuário
        }

    }

?>