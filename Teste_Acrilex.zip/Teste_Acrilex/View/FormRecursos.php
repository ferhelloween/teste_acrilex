<?php require_once "Cabecalho.php" ?>

<div class="row">
    <div class="col-md-12">
        <h2>Criar Novo Recurso</h2>
    </div>
</div>

<form method="post">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-group">
                <label for="nome">Nome</label>
                <input name="nome" type="text" class="form-control" placeholder="Nome do Recurso">
            </div>
            <div class="form-group">
                <label for="nome">Ano de Fabricação</label>
                <input name="ano" type="text" class="form-control" placeholder="Ano de Fabricação">
            </div>
            <div class="form-group">
                <label for="nome">Cor</label>
                <input name="cor" type="text" class="form-control" placeholder="Cor">
            </div>
            <div class="form-group">
                <label for="nome">Valor</label>
                <input name="valor" type="text" class="form-control" placeholder="R$ Valor">
            </div>
            <button type="submit" class="btn btn-success btn-block" value="Salvar" name="Salvar" formaction="../Controller/ControllerRecursos.php?opcao=Salvar">
                Salvar
            </button>
        </div>
    </div>
</form>
