<?php 

setlocale(LC_ALL, "pt_BR"); 
header('Content-type: text/html; charset=utf-8'); 

include_once "Template.php";

?> 