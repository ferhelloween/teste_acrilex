<?php require_once 'global.php' ?>
<?php
    try {
        $id = $_GET['id'];
        $recursos = new Recursos($id);
    } catch (Exception $e) {
        Erro::trataErro($e);
    }
?>
<?php require_once 'cabecalho.php' ?>

<div class="row">
    <div class="col-md-12">
        <h2>Criar Novo Recurso</h2>
    </div>
</div>

<form method="post">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <input type="hidden" name="id" value="<?php echo $recursos->getId() ?>">
            
            <div class="form-group">
                <label for="nome">Nome</label>
                <input name="nome" value="<?=$recursos->getName() ?>" type="text" class="form-control" placeholder="Nome do Recurso">
            </div>
            <div class="form-group">
                <label for="nome">Ano de Fabricação</label>
                <input name="ano" value="<?=$recursos->getYear() ?>" type="text" class="form-control" placeholder="Ano de Fabricação">
            </div>
            <div class="form-group">
                <label for="nome">Cor</label>
                <input name="cor" value="<?=$recursos->getColor() ?>" type="text" class="form-control" placeholder="Cor">
            </div>
            <div class="form-group">
                <label for="nome">Valor</label>
                <input name="valor" value="<?=$recursos->getPantoneValue() ?>" type="text" class="form-control" placeholder="R$ Valor">
            </div>
            <button type="submit" class="btn btn-success btn-block" value="Alterar" name="Alterar" formaction="../Controller/ControllerRecursos.php?opcao=Alterar">
                Salvar
            </button>
        </div>
    </div>
</form>
