<?php 

    ini_set('display_errors',1);
    ini_set('display_startup_erros',1);
    error_reporting(E_ALL);

    

    require_once "../Global.php";
    require_once "Cabecalho.php"; 

       $listaUsers = new Usuarios(); 
       $listaRecursos = new Recursos(); 
       
       $listaUsers->listarUsuarios(); 
       $listaRecursos->listarRecurso();

 ?> 

<div class="row">
    <div class="col-md-12">
        <h2>Sistema de Teste para Acrilex</h2>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <a href="FormUsuarios.php" class="btn btn-info btn-block">Criar novo usuário</a>
    </div>
</div>
<br>

<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered ">
            <thead>
                <tr class="bg-primary">
                    <th>Id</th>
                    <th>Email</th>
                    <th>Primeiro Nome</th>
                    <th>Segundo Nome</th>
                    <th>Foto</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listaUsers as $linhaUser) : ?>
                <tr>
                    <td><?=$linhaUser['id']?></td>
                    <td><?=$linhaUser['email']?></td>
                    <td><?=$linhaUser['first_name']?></td>
                    <td><?=$linhaUser['last_name']?></td>
                    <td><?=$linhaUser['avatar']?></td>
                    <td><a href="FormEditUsuarios.php?id=<?=$linhaUser['id']?>" class="btn btn-info">Editar</a></td>
                    <td><a href="ControllerUsuarios.php?opcao=Excluir" class="btn btn-danger">Excluir</a></td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>
   
<div class="row">
    <div class="col-md-4">
        <a href="FormRecursos.php" class="btn btn-info btn-block">Criar novo recurso</a>
    </div>
</div>
<br>

<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered ">
            <thead>
                <tr class="bg-primary">
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Ano</th>
                    <th>Cor</th>
                    <th>Valor</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listaRecursos as $linhaRecursos) : ?>
                <tr>
                    <td><?=$linhaRecursos['id']?></td>
                    <td><?=$linhaRecursos['name']?></td>
                    <td><?=$linhaRecursos['year']?></td>
                    <td><?=$linhaRecursos['color']?></td>
                    <td><?=$linhaRecursos['pantone_value']?></td>
                    <td><a href="FormEditRecursos.php?id=<?=$linhaRecursos['id']?>" class="btn btn-info">Editar</a></td>
                    <td><a href="ControllerRecuros.php?opcao=Excluir" class="btn btn-danger">Excluir</a></td> 
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

