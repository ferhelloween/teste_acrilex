<?php 

    require_once "Conexao.php";

    class Usuarios { 

        protected $id; 
        protected $email; 
        protected $first_name; 
        protected $last_name; 
        protected $avatar; 

        public function __construct($id = false) { 
              
            if($id) { 
                $this->id = $id; 
                $this->listarUmUsuario();    
            }

        }


        //Métodos Getters 
        public function getId() { 
            return $this->id;             
        }

        public function getEmail() { 
            return $this->email;             
        }

        public function getFirst() { 
            return $this->first_name; 
        }

        public function getLast() { 
            return $this->last; 
        }

        public function getAvatar() { 
            return $this->avatar; 
        }

        //Métodos Setters 
        public function setId($id) { 
            $this->id = $id;             
        }

        public function setEmail($email) { 
            $this->email = $email; 
        }

        public function setFirst($first_name) { 
            $this->first_name = $first_name;             
        }

        public function setLast($last_name) { 
            $this->last_name = $last_name; 
        }

        public function setAvatar($avatar) { 
            $this->avatar = $avatar;            
        }


        //Métodos de acesso a Dados 
        public function criarUsuario() { 
            //Cria a Query para Inserção
            $query = "INSERT INTO `Users`(`email`, `first_name`, `last_name`, `avatar`) 
            VALUES (:email, :first_name, :last_name, :avatar)";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':email', $this->getEmail()); 
            $stmt->bindValue(':first_name', $this->getFirst()); 
            $stmt->bindValue(':last_name', $this->getLast()); 
            $stmt->bindValue(':avatar', $this->getAvatar()); 
            $stmt->execute(); //Executa a Consulta     
        }

        public function editarUsuario() { 
            
            //Cria a Query para a Edição 
            $query = "UPDATE `Users` SET `email`= :email,
            `first_name`= :first_name,`last_name`= :last_name,`avatar`= :avatar WHERE id = :id"; 
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':email', $this->getEmail()); 
            $stmt->bindValue(':first_name', $this->getFirst()); 
            $stmt->bindValue(':last_name', $this->getLast()); 
            $stmt->bindValue(':avatar', $this->getAvatar());
            $stmt->bindValue(':id', $this->getId()); 
            $stmt->execute(); //Executa a Consulta  

        }

        public function excluirUsuario() { 
            $query = "DELETE FROM Users WHERE id = :id";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':id', $this->id);
            $stmt->execute();
        }

        public function listarUsuarios() { 
            //Cria a Query para fazer a listagem 
            $query = "SELECT * FROM `Users`";
            $conexao = Conexao::pegarConexao(); //Cria o arquivo para Conexão 
            $resultado = $conexao->query($query); //Prepara a Consulta
            $lista = $resultado->fetchAll(); //Cria a lista com o resultado da consulta
            
            //Retorna a lista 
            return $lista;
            
        }

        public function listarUmUsuario() { 

            $query = "SELECT * FROM `Users` WHERE id = :id";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':id', $this->id);
            $stmt->execute();
            $linha = $stmt->fetch();
                $this->email = $linha['email']; 
                $this->first_name = $linha['first_name']; 
                $this->last_name = $linha['last_name']; 
                $this->avatar = $linha['avatar']; 
        }
    }

    //Fim da Classe de Usuários
?>
