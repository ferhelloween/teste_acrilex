
<?php 

    require_once "Conexao.php";

    class Recursos { 

         protected $id; 
         protected $name; 
         protected $year; 
         protected $color; 
         protected $pantone_value; 
         
         //Construtor 
         public function __construct($id = false) { 
            if($id) { 
                $this->id = $id; 
                $this->listarUmRecurso();    
            }
        }

        //Métodos Getters 
        public function getId() { 
            return $this->id;             
        }

        public function getName() { 
            return $this->name;             
        }

        public function getYear() { 
            return $this->year; 
        }

        public function getColor() { 
            return $this->color; 
        }

        public function getPantoneValue() { 
            return $this->pantone_value; 
        }

        //Métodos Setters 
        public function setId($id) { 
            $this->id = $id;             
        }

        public function setName($name) { 
            $this->name = $name; 
        }

        public function setYear($year) { 
            $this->year = $year;             
        }

        public function setColor($color) { 
            $this->color = $color; 
        }

        public function setPantoneValue($pantone_value) { 
            $this->pantone_value = $pantone_value;            
        }


        //Métodos de acesso a Dados 
        public function criarRecurso() { 
             //Cria a Query para Inserção
             $query = "INSERT INTO `Resources`(`name`, `year`, `color`, `pantone_value`) 
             VALUES (:name, :year, :color, :pantone_value)";
             $conexao = Conexao::pegarConexao();
             $stmt = $conexao->prepare($query);
             $stmt->bindValue(':name', $this->getName()); 
             $stmt->bindValue(':year', $this->getYear()); 
             $stmt->bindValue(':color', $this->getColor()); 
             $stmt->bindValue(':pantone_value', $this->getPantoneValue()); 
             $stmt->execute(); //Executa a Consulta     
        
        }

        public function editarRecurso() { 
              //Cria a Query para a Edição 
            $query = "UPDATE `Resources` SET `name`= :name,
            `year`= :year,`color`= :color,`pantone_value`= :pantone_value WHERE id = :id"; 
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':name', $this->getName()); 
            $stmt->bindValue(':year', $this->getYear()); 
            $stmt->bindValue(':color', $this->getColor()); 
            $stmt->bindValue(':pantone_value', $this->getPantoneValue()); 
            $stmt->bindValue(':id', $this->getId()); 
            $stmt->execute(); //Executa a Consulta  
  
        }

        public function excluirRecurso() { 
            $query = "DELETE FROM Resources WHERE id = :id";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':id', $this->id);
            $stmt->execute();
        }

        public function listarRecurso() { 
             //Cria a Query para fazer a listagem 
            $query = "SELECT * FROM `Resources`";
            $conexao = Conexao::pegarConexao(); //Cria o arquivo para Conexão 
            $resultado = $conexao->query($query); //Prepara a Consulta
            $lista = $resultado->fetchAll(); //Cria a lista com o resultado da consulta
            
            //Retorna a lista 
            return $lista;
        
        }

        public function listarUmRecurso() { 
            $query = "SELECT * FROM `Resources` WHERE id = :id";
            $conexao = Conexao::pegarConexao();
            $stmt = $conexao->prepare($query);
            $stmt->bindValue(':id', $this->getId);
            $stmt->execute();
            $linha = $stmt->fetch();
                $this->name = $linha['name']; 
                $this->year = $linha['year']; 
                $this->color = $linha['color']; 
                $this->pantone_value = $linha['pantone_value']; 
        }

    }

?>