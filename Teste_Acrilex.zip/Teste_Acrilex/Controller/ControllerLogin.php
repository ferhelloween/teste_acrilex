
<?php

require_once "../Global.php";

set_time_limit(1200); //Define tempo limite de execução
ERROR_REPORTING (E_ERROR);  //Somente exibe erros fatais  

$opcao = isset($_GET['opcao']) ? $_GET['opcao'] : '';
$valor = isset($_GET['valor']) ? $_GET['valor'] : '';    

    switch($opcao) { 
       
        case "Registrar": 
            try {
                $email = $_REQUEST['Email']; 
                $senha = $_REQUEST['Senha']; 
                
                $login = new Login(); 
                $login->setEmail($email); 
                $login->setPassword($senha); 

                $login->criarLogin(); //Instancia o Objeto 

                echo "
                   <BR>
                    <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                       Cadastrado com Sucesso	
                </p>	
                
                <p style='margin-left: 15px; font-family: Arial, Helvetica, sans-serif; color: #066fa8'>
                    <a href='../VIEW/formCriaLogin.php>Clique aqui para retornar a tela de Registro</a>
                </p> 
                "; 

                
            } catch (Exception $e) {
                Erro::trataErro($e); 
            }
        
        break;

        case 'Logar':    
            try {
                $email = $_REQUEST['Email']; 
                $senha = $_REQUEST['Senha']; 
                
                $login = new Login();
                $usuario = $login->tratarLogin($email, $password); 

                    if($usuario != NULL) { 
                        header('Location: ../VIEW/Tabela.php');                         
                    } else { 
                        echo "Usuario não encontrado!"; 
                        header('Location: ../Index.php');
                    }

            } catch (Exception $e) {
                Erro::trataErro($e);
            }

              

        default: 
            //Padrão Vazio    
        break;

    }


?> 